package com.sg.testScripts;

import com.sg.driver.DriverScript;

public class TestModuleScripts extends DriverScript{

}
