package com.sg.methods;

import com.sg.driver.DriverScript;

public class UserModuleMethods extends DriverScript{

}
